<?php 
include "connection.php";
session_start();
// Register Form
if(isset($_POST['signup'])){
   $name = $_POST['name'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $retype_password = $_POST['retype_password'];

   if($password == $retype_password){
        // Insert Query
        $run = mysqli_query($con,"INSERT INTO registers(name,email,password,role)VALUES('$name','$email','$password','User')");

        if($run){
            $_SESSION['success'] = "Account Created Successfully";
            header('location:signup.php');
        }else{
            $_SESSION['msg'] = "Account Not Created";
            header('location:signup.php');
        }
        
   }else{
        $_SESSION['msg'] = "Password And Retypeword Not Match";
        header('location:signup.php');
   }
}
   // Login COding
if(isset($_POST['login'])){
   $email = $_POST['email'];
   $password = $_POST['password'];

   $FetchData = mysqli_query($con,"SELECT * FROM register WHERE email = '$email' AND password='$password'");

   if($isDataExists = mysqli_num_rows($FetchData) > 0){
       
       while($data = mysqli_fetch_assoc($FetchData)){
           
           // Admin Or User
           if($data['role'] == "Admin"){
               
               header('location:Admin_DASHBOARD/PageManagment.php?index');

           } else{
               echo "User Dashboard";
           }
       }
   }else{
       $_SESSION['msg'] = "Email Or Password Not Correct";
       header('location:login.php');
   }
}


?>
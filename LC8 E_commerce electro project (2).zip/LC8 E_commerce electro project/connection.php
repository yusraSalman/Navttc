<?php 
    $con = mysqli_connect("localhost","root","","project");
?>
<?php
session_Start();
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Login Form</title>
  </head>
  <body>
  

  <div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L2EwMDkta2Fib29tcGljcy0wMDEuanBn.jpg?s=AOtFjDBNL66tbwIeYhaevGA8GY_FbIwY0AW90CJlOW8');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <div class="mb-4">
              <h3>Sign up</h3>
             
        <?php 
            // Session Set Or Not Set
            if(isset($_SESSION['msg'])){
                echo "<div class='alert alert-danger' role='alert'>$_SESSION[msg]</div>";
                unset($_SESSION['msg']);
            }
        ?>
             
            </div>
            
            <!-- <form action="code.php" method="POST"> -->
            <form class="p-3 mt-3" method="POST" action="code.php">
              <div class="form-group first">
              <span class="far fa-user"></span>
              <label for="username">Username</label>
             
                <input type="text" class="form-control" id="username">

              </div>
              <div class="form-group ">
              <i class="fa-solid fa-envelope"></i>
              <label for="email">Email</label>
             
                <input type="text" class="form-control" id="username">

              </div>
             
           

              <div class="form-group  mb-3">
              <span class="fas fa-key"></span>
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password">
                </div>
                <div class="form-group last mb-3">
              <span class="fas fa-key"></span>
                <label for="retype_password">Retype_Password</label>
                <input type="retype_password" class="form-control" id="retype_password">
                </div>

                <input type="submit" value="Register" class="btn btn-block btn-primary">
            <a  class="text-center text-danger d-flex justify-content-center mt-3 fw-bold" href="login.php">Already have an account</a>
              
            </form>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
<?php 
include "connection.php";
session_start();
// Register Form
if(isset($_POST['signup'])){
   $name = $_POST['name'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $retype_password = $_POST['retype_password'];
  
   if($password == $retype_password){
      $run=mysqli_query($con,"INSERT Into register (name,email,password,role)VALUES
    ('$name','$email','$password','User')" ); 
    if($run)
    $_SESSION['msg'] = "account created  sucessfully";
    header('location:signup.php');
    

   }else{
        $_SESSION['msg'] = "Password And Retypeword Not Match";
        header('location:signup.php');
   }
   }

?>
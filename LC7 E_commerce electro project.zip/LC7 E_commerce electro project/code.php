<?php 
include "connection.php";
session_start();
// Register Form
if(isset($_POST['signup'])){
   $name = $_POST['name'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $retype_password = $_POST['retype_password'];

   if($password == $retype_password){
        // Insert Query
        $run = mysqli_query($con,"INSERT INTO register(name,email,password,role)VALUES('$name','$email','$password','User')");

        if($run){
            $_SESSION['success'] = "Account Created Successfully";
            header('location:signup.php');
        }else{
            $_SESSION['msg'] = "Account Not Created";
            header('location:signup.php');
        }
        
   }else{
        $_SESSION['msg'] = "Password And Retypeword Not Match";
        header('location:signup.php');
   }
}

// Login COding
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $FetchData = mysqli_query($con,"SELECT * FROM register WHERE email = '$email' AND password='$password'");

    if($isDataExists = mysqli_num_rows($FetchData) > 0){
        
        while($data = mysqli_fetch_assoc($FetchData)){
            
            // Admin Or User
            if($data['role'] == "Admin"){
                $_SESSION['name'] = $data['name'];
                header('location:Admin_DASHBOARD/PageManagment.php?index');

            } else{
                echo "User Dashboard";
            }
        }
    }else{
        $_SESSION['msg'] = "Email Or Password Not Correct";
        header('location:login.php');
    }
}


// Add Category

if(isset($_POST['addCategory'])){
    $file_name = $_FILES['category_file']['name'];
    $file_size = $_FILES['category_file']['size']; //Bytes
    $file_extension = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
    $tmp_name = $_FILES['category_file']['tmp_name'];

    $destinatin = "Admin_Dashboard/Images/".$file_name;

   if($file_extension == "png" OR $file_extension == "jpeg" OR $file_extension == "jpg" OR $file_extension == "jfif"){
    
    // Valid Size
        if($file_size <= 2000000){
                // Move File To Destination
                if(move_uploaded_file($tmp_name,$destinatin)){
                    // Insert Query
                    $c_name = $_POST['category_name'];
                    $run = mysqli_query($con,"INSERT INTO category(c_name,c_image)VALUES('$c_name','$file_name')");
                    if($run){
                        $_SESSION['success'] = "Category Added Successfully";
                        header('location:Admin_DASHBOARD/PageManagment.php?category');
                    }else{
                        $_SESSION['error'] = "Category Not Added";
                        header('location:Admin_DASHBOARD/PageManagment.php?category');
                    }

                }else{
                    $_SESSION['error'] = "File Not Uploaded";
                    header('location:Admin_DASHBOARD/PageManagment.php?category');
                }
        }else{
            $_SESSION['error'] = "File Size Must Be Less Then 2MB";
            header('location:Admin_DASHBOARD/PageManagment.php?category');
        }
   }else{
        $_SESSION['error'] = "File Type Must Be jpg Or png Or jfif";
        header('location:Admin_DASHBOARD/PageManagment.php?category');
   }
}

// Add Product

if(isset($_POST['addProduct'])){
    $file_name = $_FILES['product_file']['name'];
    $file_size = $_FILES['product_file']['size']; //Bytes
    $file_extension = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
    $tmp_name = $_FILES['product_file']['tmp_name'];

    $destinatin = "Admin_Dashboard/Images/".$file_name;

   if($file_extension == "png" OR $file_extension == "jpeg" OR $file_extension == "jpg" OR $file_extension == "jfif"){
    
    // Valid Size
        if($file_size <= 2000000){
                // Move File To Destination
                if(move_uploaded_file($tmp_name,$destinatin)){
                    // Insert Query
                    
                    $run = mysqli_query($con,"INSERT INTO product(p_name,p_desc,p_price,p_qty,p_status,p_category,p_image)VALUES('".$_POST['p_name']."','".$_POST['p_desc']."','".$_POST['p_price']."','".$_POST['p_qty']."','".$_POST['p_status']."','".$_POST['p_category']."','$file_name')");

                    if($run){
                        $_SESSION['success'] = "Product Added Successfully";
                        header('location:Admin_DASHBOARD/PageManagment.php?product');
                    }else{
                        $_SESSION['error'] = "Product Not Added";
                        header('location:Admin_DASHBOARD/PageManagment.php?product');
                    }

                }else{
                    $_SESSION['error'] = "File Not Uploaded";
                    header('location:Admin_DASHBOARD/PageManagment.php?product');
                }
        }else{
            $_SESSION['error'] = "File Size Must Be Less Then 2MB";
            header('location:Admin_DASHBOARD/PageManagment.php?product');
        }
   }else{
        $_SESSION['error'] = "File Type Must Be jpg Or png Or jfif";
        header('location:Admin_DASHBOARD/PageManagment.php?product');
   }
}
?>